Please have a look at [this wiki page](https://github.com/valums/file-uploader/wiki/Rails---CarrierWave) if you are using Rails
