Install NuGet package FineUploader.AspNet.Mvc (http://nuget.org/packages/FineUploader.AspNet.Mvc)

_OR_

1. Drop these files into your project:
 - FineUpload.cs
 - FineUploadResult.cs
2. Reference Newtonsoft.Json
3. Look at UploadController.cs for example of handling uploaded files.
4. To upload larger files, take a look at web.config
